//
//  ViewController.swift
//  Constellations
//
//  Created by 林郁琦 on 2024/1/21.
//

import UIKit
import Foundation

//利用結構 (Struct) Sign，用來表示星座的名稱和相應的圖片名稱
struct Sign {
    let name: String
    let pic: String
}

class ViewController: UIViewController {
    
    @IBOutlet weak var constellationLabel: UILabel!
    
    @IBOutlet weak var constellationImageView: UIImageView!
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var preButton: UIButton!
    
    @IBOutlet var swipe: UISwipeGestureRecognizer!
    
    
    let waterSign: [Sign] = [Sign(name: "巨蠍座", pic: "巨蠍座" ),Sign(name: "天蠍座", pic: "天蠍座"),Sign(name: "雙魚座", pic: "雙魚座")]
    let fireSign: [Sign] = [Sign(name: "牡羊座", pic: "牡羊座"),Sign(name: "獅子座", pic: "獅子座"),Sign(name: "射手座", pic: "射手座")]
    let earthSign: [Sign] = [Sign(name: "摩羯座", pic: "摩羯座"),Sign(name: "金牛座", pic: "金牛座"),Sign(name: "處女座", pic: "處女座")]
    let airSign: [Sign] = [Sign(name: "水瓶座", pic: "水瓶座"),Sign(name: "雙子座", pic: "雙子座"),Sign(name: "天秤座", pic: "天秤座")]
    
    
    func changeImage() {
        let sign: Sign
        if segmentedControl.selectedSegmentIndex == 0 {
            sign = waterSign[pageControl.currentPage]
        } else if segmentedControl.selectedSegmentIndex == 1 {
            sign = fireSign[pageControl.currentPage]
        } else if segmentedControl.selectedSegmentIndex == 2 {
            sign = earthSign[pageControl.currentPage]
        } else {
            sign = airSign[pageControl.currentPage]
        }
        constellationLabel.text = sign.name
        constellationImageView.image = UIImage(named: sign.pic)
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        constellationImageView.layer.cornerRadius = 40
        constellationImageView.image = UIImage(named: "巨蠍座")
        
        
    }
    
    @IBAction func nextButton(_ sender: Any) {
        pageControl.currentPage += 1
        changeImage()
    }
    
    
    @IBAction func preButton(_ sender: Any) {
        pageControl.currentPage -= 1
        if pageControl.currentPage == -1 {
            pageControl.currentPage = pageControl.numberOfPages - 1
        }
        changeImage()
    }
    
    @IBAction func pageControl(_ sender: UIPageControl) {
        changeImage()
    }
    @IBAction func segmentedControl(_ sender: UISegmentedControl) {
        pageControl.currentPage = 0
        changeImage()
    }
    
    
    
    @IBAction func swipe(_ sender: UISwipeGestureRecognizer) {
        if sender.direction == .right {
        } else if sender.direction == .left {
            
        }
    }
}



